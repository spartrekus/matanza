/* Define to `int' if <> doesn't define it. */
#undef socklen_t
